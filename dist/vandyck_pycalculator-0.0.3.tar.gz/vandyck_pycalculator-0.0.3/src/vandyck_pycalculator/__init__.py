from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial
from .Generaldistribution import General
